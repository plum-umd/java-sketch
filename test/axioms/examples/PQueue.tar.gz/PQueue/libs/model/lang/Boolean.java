class Boolean {

    boolean bool;
    
    public Boolean(boolean bool) {
	this.bool = bool;
    }

    boolean booleanValue() {
	return this.bool;
    }
}
