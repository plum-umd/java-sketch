package java.lang;

public abstract class Number {

    public abstract int intValue();

}
