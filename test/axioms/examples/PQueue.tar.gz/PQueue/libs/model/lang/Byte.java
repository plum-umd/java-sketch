public class Byte {
    byte b;
    public Byte(byte b) {
	this.b = b;
	
    }

    public byte byteValue() {
	return b;
    }
}
