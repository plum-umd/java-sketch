package java.lang;

public interface CharSequence {
  public char charAt(int index);
  public int length();
  public String toString();
}
